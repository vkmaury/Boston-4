import Contact from "@/src/components/Contact";
import Footer from "@/src/components/Footer";
import Header from "@/src/components/Header";
import Home from "@/src/components/Home";
import Portfolio from "@/src/components/Portfolio";
import Services from "@/src/components/Services";
import Skill from "@/src/components/Skill";
import Testimonial from "@/src/components/Testimonial";
import ImageView from "@/src/components/popup/ImageView";
import { boston } from "@/src/utils";
import { Fragment, useEffect, useState } from "react";

const API =
  "https://portfolio-backend-30mp.onrender.com/api/v1/get/user/65b3a22c01d900e96c4219ae";
const Index = () => {
  useEffect(() => {
    boston.scrollToActiveNav();
    boston.imgToSvg();
  }, []);

  const [user, setUser] = useState([]);

  useEffect(() => {
    fetchUser(API);
  }, []);

  const fetchUser = async (url) => {
    try {
      const res = await fetch(url);
      const data = await res.json();
      if (data.success === true) {
        setUser(data.user);
      }
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <Fragment>
      <ImageView />
      {/* End */}
      {/* Header */}
      <Header />
      {/* End Header */}
      {/* Main */}
      <main className="wrapper">
        {/* Home Section */}
        <Home />
        {/* End Home Section */}
        {/* Services Section */}
        <Services user={user} />
        
        {/* End Services Section */}
        {/* Skill Section */}
        <Skill  user={user}/>
        {/* End Skill Section */}
        {/* Work Section */}
        <Portfolio user={user} />
        {/* End Work Section */}
        {/* testimonial Section */}
        <Testimonial user={user} />
        {/* End testimonial Section */}
        {/* Contact Section */}
        <Contact />
        {/* End Contact Section */}
        {/* Effect */}
        <div className="right-effects" />
        <div className="left-effects" />
        {/* End Effect */}
      </main>
      {/* Main */}
      {/* Footer */}
      <Footer user={user} />
      {/* End Footer */}
    </Fragment>
  );
};
export default Index;
