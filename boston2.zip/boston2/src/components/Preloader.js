const Preloader = () => {
  return (
    <div id="loading">
      <div className="load-circle">
        <span className="one" />
      </div>
    </div>
  );
};
export default Preloader;
