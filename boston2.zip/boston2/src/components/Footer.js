const Footer = ({ user }) => {
  const { social_handles } = user; 
  return (

    <footer className="footer">
      <div className="container">
        <div className="row align-items-center">
          <div className="col-md-6 py-2">
            <div className="nav justify-content-center justify-content-md-start">
            {social_handles &&
            social_handles.map((social_handle, index) => (
              
              <a key={social_handle._id} href="#">
              <img className="img" src={social_handle.image.url} alt={social_handle.platform} />
            </a>
          ))}
        
            </div>
          </div>
          <div className="col-md-6 py-2 text-center text-md-end">
            <p className="m-0">
              © {new Date().getFullYear()} copyright all right reserved
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};
export default Footer;
